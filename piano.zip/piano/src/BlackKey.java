import javax.swing.*;
import java.awt.*;

class BlackKey extends JButton implements Key {
    private final int note;
    BlackKey(int pos) {
        note = baseNote + 1 + 2 * pos + (pos + 3) / 5 + pos / 5;
        int left = 50 + WD + ((WD * 3) / 2) * (pos + (pos / 20)) + ((pos + 3) / 20);
        setBackground(Color.black);
        setBounds(left, 320, WD, HT);
    }

    public int getNote() {
        return note;
    }
}
