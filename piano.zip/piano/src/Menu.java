import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;

class Menu extends JFrame {
     static void createGUI() {
        JFrame frame = new JFrame("Музыкальные ступени");
        JPanel panel = new JPanel();
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {

                Object[] options = {"Да", "Нет!"};
                int n = JOptionPane.showOptionDialog(e.getWindow(), "Закрыть приложение?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
                        null, options, options[0]);
                if (n == 0) {
                    e.getWindow().setVisible(false);
                    System.exit(0);
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });

        ImagePanel pp = new ImagePanel();
        pp.setLayout(new BorderLayout());
        try {
            pp.setImage(ImageIO.read(new File("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//skinut.jpg")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        panel.setLayout(new java.awt.GridLayout());
        panel.setOpaque(false);

     //   JMenuBar menuBar = new JMenuBar();

        JButton button1 = new JButton();
        button1.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Knopka_Pley.png"));
        button1.setBorderPainted(false);
        button1.setFocusPainted(false);
        button1.setContentAreaFilled(false);
        button1.setSize(new Dimension(400,400));
        button1.setLocation(900,300);
        button1.setToolTipText("Начать игру");
        frame.add(button1);
        button1.addActionListener(e -> {
            frame.setVisible(false);
            SwingUtilities.invokeLater(() -> new Piano().createAndShowGUI());
        });

        JButton button2 = new JButton();
        button2.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Knopka_Vykhod.png"));
        button2.setBorderPainted(false);
        button2.setFocusPainted(false);
        button2.setContentAreaFilled(false);
        button2.setSize(new Dimension(80,80));
        button2.setLocation(10,10);
        button2.addActionListener(e -> System.exit(0));
        button2.setToolTipText("Выйти из приложения");
        frame.add(button2);

        pp.add(panel, BorderLayout.NORTH);
        pp.setPreferredSize(new Dimension(1000,700));
        frame.add(new JScrollPane(pp));
        frame.pack();

        frame.setPreferredSize(new Dimension(1600, 1024));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}