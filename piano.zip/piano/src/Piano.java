import javax.imageio.ImageIO;
import javax.sound.midi.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

public class Piano extends JFrame implements KeyListener, MouseListener {
    private final int OCTAVES = 3; //number of octaves
    private WhiteKey[] whites = new WhiteKey[7 * OCTAVES]; //number of white keys
    private BlackKey[] blacks = new BlackKey[7 * OCTAVES]; //number of black keys
    private JFrame frame;

    private final ThreadLocal<MidiChannel> channel = new ThreadLocal<>(); //set channel

    Piano() {
        try {
            Synthesizer synth = MidiSystem.getSynthesizer();
            synth.open();
            synth.loadAllInstruments(synth.getDefaultSoundbank());
            Instrument[] insts = synth.getLoadedInstruments();
            MidiChannel channels[] = synth.getChannels();
            int i = 0;
            while (i < channels.length) {
                if (channels[i] != null) {
                    channel.set(channels[i]);
                    break;
                }
                i++;
            }
            for (i = 0; i < insts.length; i++) {
                if (insts[i].toString().startsWith("Instrument MidiPiano")) {
                    channel.get().programChange(i);
                    break;
                }
            }
        } catch (MidiUnavailableException ex) {
            ex.printStackTrace();
        }
    }

    //enter key
    public void keyPressed(KeyEvent e) {


        Key key = (Key) e.getSource();
        if (key != null) {

            // small octave begins
            if (e.getKeyCode() == 65) {
                channel.get().noteOn(48, 127);
            }
            if (e.getKeyCode() == 83) {
                channel.get().noteOn(49, 127);
            }
            if (e.getKeyCode() == 68) {
                channel.get().noteOn(50, 127);
            }
            if (e.getKeyCode() == 70) {
                channel.get().noteOn(51, 127);
            }
            if (e.getKeyCode() == 71) {
                channel.get().noteOn(52, 127);
            }
            if (e.getKeyCode() == 90) {
                channel.get().noteOn(53, 127);
            }
            if (e.getKeyCode() == 88) {
                channel.get().noteOn(54, 127);
            }
            if (e.getKeyCode() == 67) {
                channel.get().noteOn(55, 127);
            }
            if (e.getKeyCode() == 86) {
                channel.get().noteOn(56, 127);
            }
            if (e.getKeyCode() == 66) {
                channel.get().noteOn(57, 127);
            }
            if (e.getKeyCode() == 72) {
                channel.get().noteOn(58, 127);
            }
            if (e.getKeyCode() == 78) {
                channel.get().noteOn(59, 127);
            }
            //small octave ends

            //first octave begins
            if (e.getKeyCode() == 81) {
                channel.get().noteOn(60, 127);
            }
            if (e.getKeyCode() == 87) {
                channel.get().noteOn(61, 127);
            }
            if (e.getKeyCode() == 69) {
                channel.get().noteOn(62, 127);
            }
            if (e.getKeyCode() == 82) {
                channel.get().noteOn(63, 127);
            }
            if (e.getKeyCode() == 84) {
                channel.get().noteOn(64, 127);
            }
            if (e.getKeyCode() == 89) {
                channel.get().noteOn(65, 127);
            }
            if (e.getKeyCode() == 85) {
                channel.get().noteOn(66, 127);
            }
            if (e.getKeyCode() == 73) {
                channel.get().noteOn(67, 127);
            }
            if (e.getKeyCode() == 79) {
                channel.get().noteOn(68, 127);
            }
            if (e.getKeyCode() == 80) {
                channel.get().noteOn(69, 127);
            }
            if (e.getKeyCode() == 77) {
                channel.get().noteOn(70, 127);
            }
            if (e.getKeyCode() == 48) {
                channel.get().noteOn(71, 127);
            }
            //first octave ends

            //second octave begins
            if (e.getKeyCode() == 74) {
                channel.get().noteOn(72, 127);
            }
            if (e.getKeyCode() == 75) {
                channel.get().noteOn(73, 127);
            }
            if (e.getKeyCode() == 76) {
                channel.get().noteOn(74, 127);
            }
            if (e.getKeyCode() == 49) {
                channel.get().noteOn(75, 127);
            }
            if (e.getKeyCode() == 50) {
                channel.get().noteOn(76, 127);
            }
            if (e.getKeyCode() == 51) {
                channel.get().noteOn(77, 127);
            }
            if (e.getKeyCode() == 52) {
                channel.get().noteOn(78, 127);
            }
            if (e.getKeyCode() == 53) {
                channel.get().noteOn(79, 127);
            }
            if (e.getKeyCode() == 54) {
                channel.get().noteOn(80, 127);
            }
            if (e.getKeyCode() == 55) {
                channel.get().noteOn(81, 127);
            }
            if (e.getKeyCode() == 56) {
                channel.get().noteOn(82, 127);
            }
            if (e.getKeyCode() == 57) {
                channel.get().noteOn(83, 127);
            }
            //second octave ends
        }

    }

    //release key
    public void keyReleased(KeyEvent e) {
        Key key = (Key) e.getSource();
        if (key != null) {
            //small octave begins
            if (e.getKeyCode() == 65) {
                channel.get().noteOff(48);
            }
            if (e.getKeyCode() == 83) {
                channel.get().noteOff(49);
            }
            if (e.getKeyCode() == 68) {
                channel.get().noteOff(50);
            }
            if (e.getKeyCode() == 70) {
                channel.get().noteOff(51);
            }
            if (e.getKeyCode() == 71) {
                channel.get().noteOff(52);
            }
            if (e.getKeyCode() == 90) {
                channel.get().noteOff(53);
            }
            if (e.getKeyCode() == 88) {
                channel.get().noteOff(54);
            }
            if (e.getKeyCode() == 67) {
                channel.get().noteOff(55);
            }
            if (e.getKeyCode() == 86) {
                channel.get().noteOff(56);
            }
            if (e.getKeyCode() == 66) {
                channel.get().noteOff(57);
            }
            if (e.getKeyCode() == 72) {
                channel.get().noteOff(58);
            }
            if (e.getKeyCode() == 78) {
                channel.get().noteOff(59);
            }
            //small octave ends

            //first octave begins
            if (e.getKeyCode() == 81) {
                channel.get().noteOff(60);
            }
            if (e.getKeyCode() == 87) {
                channel.get().noteOff(61);
            }
            if (e.getKeyCode() == 69) {
                channel.get().noteOff(62);
            }
            if (e.getKeyCode() == 82) {
                channel.get().noteOff(63);
            }
            if (e.getKeyCode() == 84) {
                channel.get().noteOff(64);
            }
            if (e.getKeyCode() == 89) {
                channel.get().noteOff(65);
            }
            if (e.getKeyCode() == 85) {
                channel.get().noteOff(66);
            }
            if (e.getKeyCode() == 73) {
                channel.get().noteOff(67);
            }
            if (e.getKeyCode() == 79) {
                channel.get().noteOff(68);
            }
            if (e.getKeyCode() == 80) {
                channel.get().noteOff(69);
            }
            if (e.getKeyCode() == 77) {
                channel.get().noteOff(70);
            }
            if (e.getKeyCode() == 48) {
                channel.get().noteOff(71);
            }
            //first octave ends

            //second octave begins
            if (e.getKeyCode() == 74) {
                channel.get().noteOff(72);
            }
            if (e.getKeyCode() == 75) {
                channel.get().noteOff(73);
            }
            if (e.getKeyCode() == 76) {
                channel.get().noteOff(74);
            }
            if (e.getKeyCode() == 49) {
                channel.get().noteOff(75);
            }
            if (e.getKeyCode() == 50) {
                channel.get().noteOff(76);
            }
            if (e.getKeyCode() == 51) {
                channel.get().noteOff(77);
            }
            if (e.getKeyCode() == 52) {
                channel.get().noteOff(78);
            }
            if (e.getKeyCode() == 53) {
                channel.get().noteOff(79);
            }
            if (e.getKeyCode() == 54) {
                channel.get().noteOff(80);
            }
            if (e.getKeyCode() == 55) {
                channel.get().noteOff(81);
            }
            if (e.getKeyCode() == 56) {
                channel.get().noteOff(82);
            }
            if (e.getKeyCode() == 57) {
                channel.get().noteOff(83);
            }
            //second octave ends
        }
    }
    public void keyTyped (KeyEvent e) { }

    //enter mouse
    public void mousePressed (MouseEvent e) {
        Key key = (Key) e.getSource();
        if (key != null) {
            channel.get().noteOn(key.getNote(), 127);
        }
    }

    //release mouse
    public void mouseReleased (MouseEvent e) {
        Key key = (Key) e.getSource();
        if (key != null) {
            channel.get().noteOff(key.getNote());
        }
    }

    public void mouseClicked (MouseEvent e) { }
    public void mouseEntered (MouseEvent e) { }
    public void mouseExited (MouseEvent e) { }


    void createAndShowGUI() {

        frame = new JFrame("Пианино");
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); //exit with close

        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {

                Object[] options = {"Да", "Нет!"};
                int n = JOptionPane.showOptionDialog(e.getWindow(), "Закрыть приложение?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
                        null, options, options[0]);
                if (n == 0) {
                    e.getWindow().setVisible(false);
                    System.exit(0);
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });

        ImagePanel pp = new ImagePanel();
        pp.setLayout(new BorderLayout());
        try {
            pp.setImage(ImageIO.read(new File("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Fon.jpg")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        JLayeredPane contentPane = new JLayeredPane()
        {
            @Override
            public Dimension getPreferredSize()
            {
                int count = getComponentCount();
                Component last = getComponent(count - 1);
                Rectangle bounds = last.getBounds();
                int width = 10 + bounds.x + bounds.width;
                int height = 10 + bounds.y + bounds.height;

                return new Dimension(width, height);
            }
        };
        contentPane.setLayout(null);

        //fill whites keys into contentPane
        for (int i = 0; i < whites.length; i++) {
            int k = i;
            whites[i] = new WhiteKey(i);
            contentPane.add(whites[i], 1, 0);
            whites[i].addMouseListener(this);
            whites[i].addKeyListener(this);
            contentPane.setComponentZOrder(whites[i], k);
        }

        //fill blacks keys into contentPane
        for (int i = 0; i < blacks.length; i++) {
            int j = i % 7;
            if (j == 2 || j == 6) {
                continue;
            }

            blacks[i] = new BlackKey(i);
            contentPane.add(blacks[i], 2, 0);
            blacks[i].addMouseListener(this);
            blacks[i].addKeyListener(this);
            contentPane.setComponentZOrder(blacks[i], 0);
        }

        JButton button = new JButton();
        button.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//knopka_nazad.png"));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setSize(new Dimension(80,80));
        button.setLocation(10,10);
        button.setToolTipText("Перейти к главному меню");
        frame.add(button);
        button.addActionListener((ActionEvent e) -> {
            frame.setVisible(false);
            new Menu();
            SwingUtilities.invokeLater(Menu::createGUI);
        });

        JButton question2 = new JButton();

        JButton question = new JButton();
        question.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Knopka_Voprosa.png"));
        question.setBorderPainted(false);
        question.setFocusPainted(false);
        question.setContentAreaFilled(false);
        question.setSize(new Dimension(80, 80));
        question.setLocation(1280, 10);
        question.setToolTipText("Справка");
        question.addActionListener((ActionEvent ee) -> {
            new Settings().refGUI();
            question.setVisible(false);
            question2.setVisible(true);
        });
        frame.add(question);

        question2.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Knopka_Voprosa.png"));
        question2.setBorderPainted(false);
        question2.setFocusPainted(false);
        question2.setContentAreaFilled(false);
        question2.setSize(new Dimension(80, 80));
        question2.setLocation(1280, 10);
        question2.setToolTipText("Справка");
        question2.addActionListener((ActionEvent ee) -> {
            new Settings().refGUI();
            question2.setVisible(false);
            question.setVisible(true);
        });
        frame.add(question2);

        Font font = new Font("Verdana", Font.PLAIN, 40);

        //start normal white keys
        JLabel a = new JLabel("A");
        a.setBounds(65, 630, 50, 50);
        a.setFont(font);
        a.setForeground(Color.black);
        a.setVisible(false);
        frame.add(a);

        JLabel d = new JLabel("D");
        d.setBounds(125, 630, 50, 50);
        d.setFont(font);
        d.setForeground(Color.black);
        d.setVisible(false);
        frame.add(d);

        JLabel g = new JLabel("G");
        g.setBounds(185, 630, 50, 50);
        g.setFont(font);
        g.setForeground(Color.black);
        g.setVisible(false);
        frame.add(g);

        JLabel z = new JLabel("Z");
        z.setBounds(245, 630, 50, 50);
        z.setFont(font);
        z.setForeground(Color.black);
        z.setVisible(false);
        frame.add(z);

        JLabel c = new JLabel("C");
        c.setBounds(305, 630, 50, 50);
        c.setFont(font);
        c.setForeground(Color.black);
        c.setVisible(false);
        frame.add(c);

        JLabel b = new JLabel("B");
        b.setBounds(365, 630, 50, 50);
        b.setFont(font);
        b.setForeground(Color.black);
        b.setVisible(false);
        frame.add(b);

        JLabel n = new JLabel("N");
        n.setBounds(425, 630, 50, 50);
        n.setFont(font);
        n.setForeground(Color.black);
        n.setVisible(false);
        frame.add(n);

        JLabel q = new JLabel("Q");
        q.setBounds(485, 630, 50, 50);
        q.setFont(font);
        q.setForeground(Color.black);
        q.setVisible(false);
        frame.add(q);

        JLabel e = new JLabel("E");
        e.setBounds(545, 630, 50, 50);
        e.setFont(font);
        e.setForeground(Color.black);
        e.setVisible(false);
        frame.add(e);

        JLabel t = new JLabel("T");
        t.setBounds(605, 630, 50, 50);
        t.setFont(font);
        t.setForeground(Color.black);
        t.setVisible(false);
        frame.add(t);

        JLabel y = new JLabel("Y");
        y.setBounds(665, 630, 50, 50);
        y.setFont(font);
        y.setForeground(Color.black);
        y.setVisible(false);
        frame.add(y);

        JLabel i = new JLabel("I");
        i.setBounds(730, 630, 50, 50);
        i.setFont(font);
        i.setForeground(Color.black);
        i.setVisible(false);
        frame.add(i);

        JLabel p = new JLabel("P");
        p.setBounds(785, 630, 50, 50);
        p.setFont(font);
        p.setForeground(Color.black);
        p.setVisible(false);
        frame.add(p);

        JLabel j0 = new JLabel("0");
        j0.setBounds(845, 630, 50, 50);
        j0.setFont(font);
        j0.setForeground(Color.black);
        j0.setVisible(false);
        frame.add(j0);

        JLabel j = new JLabel("J");
        j.setBounds(910, 630, 50, 50);
        j.setFont(font);
        j.setForeground(Color.black);
        j.setVisible(false);
        frame.add(j);

        JLabel l = new JLabel("L");
        l.setBounds(970, 630, 50, 50);
        l.setFont(font);
        l.setForeground(Color.black);
        l.setVisible(false);
        frame.add(l);

        JLabel j2 = new JLabel("2");
        j2.setBounds(1025, 630, 50, 50);
        j2.setFont(font);
        j2.setForeground(Color.black);
        j2.setVisible(false);
        frame.add(j2);

        JLabel j3 = new JLabel("3");
        j3.setBounds(1085, 630, 50, 50);
        j3.setFont(font);
        j3.setForeground(Color.black);
        j3.setVisible(false);
        frame.add(j3);

        JLabel j5 = new JLabel("5");
        j5.setBounds(1145, 630, 50, 50);
        j5.setFont(font);
        j5.setForeground(Color.black);
        j5.setVisible(false);
        frame.add(j5);

        JLabel j7 = new JLabel("7");
        j7.setBounds(1205, 630, 50, 50);
        j7.setFont(font);
        j7.setForeground(Color.black);
        j7.setVisible(false);
        frame.add(j7);

        JLabel j9 = new JLabel("9");
        j9.setBounds(1265, 630, 50, 50);
        j9.setFont(font);
        j9.setForeground(Color.black);
        j9.setVisible(false);
        frame.add(j9);
        //ends normal white keys

        //starts black keys(dies)
        JLabel s = new JLabel("S");
        s.setBounds(97, 270, 50, 50);
        s.setFont(font);
        s.setForeground(Color.white);
        s.setVisible(false);
        frame.add(s);

        JLabel f = new JLabel("F");
        f.setBounds(160, 270, 50, 50);
        f.setFont(font);
        f.setForeground(Color.white);
        f.setVisible(false);
        frame.add(f);

        JLabel x = new JLabel("X");
        x.setBounds(277, 270, 50, 50);
        x.setFont(font);
        x.setForeground(Color.white);
        x.setVisible(false);
        frame.add(x);

        JLabel v = new JLabel("V");
        v.setBounds(337, 270, 50, 50);
        v.setFont(font);
        v.setForeground(Color.white);
        v.setVisible(false);
        frame.add(v);

        JLabel h = new JLabel("H");
        h.setBounds(397, 270, 50, 50);
        h.setFont(font);
        h.setForeground(Color.white);
        h.setVisible(false);
        frame.add(h);

        JLabel w = new JLabel("W");
        w.setBounds(511, 270, 50, 50);
        w.setFont(font);
        w.setForeground(Color.white);
        w.setVisible(false);
        frame.add(w);

        JLabel r = new JLabel("R");
        r.setBounds(577, 270, 50, 50);
        r.setFont(font);
        r.setForeground(Color.white);
        r.setVisible(false);
        frame.add(r);

        JLabel u = new JLabel("U");
        u.setBounds(697, 270, 50, 50);
        u.setFont(font);
        u.setForeground(Color.white);
        u.setVisible(false);
        frame.add(u);

        JLabel o = new JLabel("O");
        o.setBounds(755, 270, 50, 50);
        o.setFont(font);
        o.setForeground(Color.white);
        o.setVisible(false);
        frame.add(o);

        JLabel m = new JLabel("M");
        m.setBounds(815, 270, 50, 50);
        m.setFont(font);
        m.setForeground(Color.white);
        m.setVisible(false);
        frame.add(m);

        JLabel k = new JLabel("K");
        k.setBounds(937, 270, 50, 50);
        k.setFont(font);
        k.setForeground(Color.white);
        k.setVisible(false);
        frame.add(k);

        JLabel j1 = new JLabel("1");
        j1.setBounds(1000, 270, 50, 50);
        j1.setFont(font);
        j1.setForeground(Color.white);
        j1.setVisible(false);
        frame.add(j1);

        JLabel j4 = new JLabel("4");
        j4.setBounds(1120, 270, 50, 50);
        j4.setFont(font);
        j4.setForeground(Color.white);
        j4.setVisible(false);
        frame.add(j4);

        JLabel j6 = new JLabel("6");
        j6.setBounds(1180, 270, 50, 50);
        j6.setFont(font);
        j6.setForeground(Color.white);
        j6.setVisible(false);
        frame.add(j6);

        JLabel j8 = new JLabel("8");
        j8.setBounds(1240, 270, 50, 50);
        j8.setFont(font);
        j8.setForeground(Color.white);
        j8.setVisible(false);
        frame.add(j8);
        //ends black keys(dies)

        Font font2 = new Font("Verdana", Font.PLAIN, 20);

        JLabel doo = new JLabel("До");
        doo.setBounds(65, 630, 50, 50);
        doo.setFont(font2);
        doo.setForeground(Color.orange);
        doo.setVisible(false);
        frame.add(doo);

        JLabel re = new JLabel("Ре");
        re.setBounds(125, 630, 50, 50);
        re.setFont(font2);
        re.setForeground(Color.orange);
        re.setVisible(false);
        frame.add(re);

        JLabel mi = new JLabel("Ми");
        mi.setBounds(185, 630, 50, 50);
        mi.setFont(font2);
        mi.setForeground(Color.orange);
        mi.setVisible(false);
        frame.add(mi);

        JLabel fa = new JLabel("Фа");
        fa.setBounds(245, 630, 50, 50);
        fa.setFont(font2);
        fa.setForeground(Color.orange);
        fa.setVisible(false);
        frame.add(fa);

        JLabel sol = new JLabel("Соль");
        sol.setBounds(297, 630, 50, 50);
        sol.setFont(font2);
        sol.setForeground(Color.orange);
        sol.setVisible(false);
        frame.add(sol);

        JLabel la = new JLabel("Ля");
        la.setBounds(370, 630, 50, 50);
        la.setFont(font2);
        la.setForeground(Color.orange);
        la.setVisible(false);
        frame.add(la);

        JLabel si = new JLabel("Си");
        si.setBounds(430, 630, 50, 50);
        si.setFont(font2);
        si.setForeground(Color.orange);
        si.setVisible(false);
        frame.add(si);

        JLabel doo1 = new JLabel("До");
        doo1.setBounds(485, 630, 50, 50);
        doo1.setFont(font2);
        doo1.setForeground(Color.blue);
        doo1.setVisible(false);
        frame.add(doo1);

        JLabel re1 = new JLabel("Ре");
        re1.setBounds(545, 630, 50, 50);
        re1.setFont(font2);
        re1.setForeground(Color.blue);
        re1.setVisible(false);
        frame.add(re1);

        JLabel mi1 = new JLabel("Ми");
        mi1.setBounds(605, 630, 50, 50);
        mi1.setFont(font2);
        mi1.setForeground(Color.blue);
        mi1.setVisible(false);
        frame.add(mi1);

        JLabel fa1 = new JLabel("Фа");
        fa1.setBounds(665, 630, 50, 50);
        fa1.setFont(font2);
        fa1.setForeground(Color.blue);
        fa1.setVisible(false);
        frame.add(fa1);

        JLabel sol1 = new JLabel("Соль");
        sol1.setBounds(717, 630, 50, 50);
        sol1.setFont(font2);
        sol1.setForeground(Color.blue);
        sol1.setVisible(false);
        frame.add(sol1);

        JLabel la1 = new JLabel("Ля");
        la1.setBounds(790, 630, 50, 50);
        la1.setFont(font2);
        la1.setForeground(Color.blue);
        la1.setVisible(false);
        frame.add(la1);

        JLabel si1 = new JLabel("Си");
        si1.setBounds(850, 630, 50, 50);
        si1.setFont(font2);
        si1.setForeground(Color.blue);
        si1.setVisible(false);
        frame.add(si1);

        JLabel doo2 = new JLabel("До");
        doo2.setBounds(905, 630, 50, 50);
        doo2.setFont(font2);
        doo2.setForeground(Color.red);
        doo2.setVisible(false);
        frame.add(doo2);

        JLabel re2 = new JLabel("Ре");
        re2.setBounds(965, 630, 50, 50);
        re2.setFont(font2);
        re2.setForeground(Color.red);
        re2.setVisible(false);
        frame.add(re2);

        JLabel mi2 = new JLabel("Ми");
        mi2.setBounds(1025, 630, 50, 50);
        mi2.setFont(font2);
        mi2.setForeground(Color.red);
        mi2.setVisible(false);
        frame.add(mi2);

        JLabel fa2 = new JLabel("Фа");
        fa2.setBounds(1085, 630, 50, 50);
        fa2.setFont(font2);
        fa2.setForeground(Color.red);
        fa2.setVisible(false);
        frame.add(fa2);

        JLabel sol2 = new JLabel("Соль");
        sol2.setBounds(1137, 630, 50, 50);
        sol2.setFont(font2);
        sol2.setForeground(Color.red);
        sol2.setVisible(false);
        frame.add(sol2);

        JLabel la2 = new JLabel("Ля");
        la2.setBounds(1210, 630, 50, 50);
        la2.setFont(font2);
        la2.setForeground(Color.red);
        la2.setVisible(false);
        frame.add(la2);

        JLabel si2 = new JLabel("Си");
        si2.setBounds(1270, 630, 50, 50);
        si2.setFont(font2);
        si2.setForeground(Color.red);
        si2.setVisible(false);
        frame.add(si2);

        JPanel mypanel = new JPanel();

        JButton visible = new JButton();

        JButton notVisible = new JButton();
        notVisible.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//letter.png"));
        notVisible.setBorderPainted(false);
        notVisible.setFocusPainted(false);
        notVisible.setContentAreaFilled(false);
        notVisible.setSize(new Dimension(70, 70));
        notVisible.setLocation(50, 30);
        notVisible.setToolTipText("Включить ноты");
        mypanel.add(notVisible);
        notVisible.addActionListener(e1 -> {
            a.setVisible(false);
            d.setVisible(false);
            g.setVisible(false);
            z.setVisible(false);
            c.setVisible(false);
            b.setVisible(false);
            n.setVisible(false);
            q.setVisible(false);
            e.setVisible(false);
            t.setVisible(false);
            y.setVisible(false);
            i.setVisible(false);
            p.setVisible(false);
            j0.setVisible(false);
            j.setVisible(false);
            l.setVisible(false);
            j2.setVisible(false);
            j3.setVisible(false);
            j5.setVisible(false);
            j7.setVisible(false);
            j9.setVisible(false);
            s.setVisible(false);
            f.setVisible(false);
            x.setVisible(false);
            v.setVisible(false);
            h.setVisible(false);
            w.setVisible(false);
            r.setVisible(false);
            u.setVisible(false);
            o.setVisible(false);
            m.setVisible(false);
            k.setVisible(false);
            j1.setVisible(false);
            j4.setVisible(false);
            j6.setVisible(false);
            j8.setVisible(false);
            doo.setVisible(true);
            re.setVisible(true);
            mi.setVisible(true);
            fa.setVisible(true);
            sol.setVisible(true);
            la.setVisible(true);
            si.setVisible(true);
            doo1.setVisible(true);
            re1.setVisible(true);
            mi1.setVisible(true);
            fa1.setVisible(true);
            sol1.setVisible(true);
            la1.setVisible(true);
            si1.setVisible(true);
            doo2.setVisible(true);
            re2.setVisible(true);
            mi2.setVisible(true);
            fa2.setVisible(true);
            sol2.setVisible(true);
            la2.setVisible(true);
            si2.setVisible(true);
            notVisible.setVisible(false);
            visible.setVisible(true);
        });

        visible.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//letter.png"));
        visible.setBorderPainted(false);
        visible.setFocusPainted(false);
        visible.setContentAreaFilled(false);
        visible.setSize(new Dimension(70, 70));
        visible.setLocation(50, 30);
        visible.setToolTipText("Включить раскладку на клавиатуре");
        mypanel.add(visible);
        visible.addActionListener(e2 -> {
            a.setVisible(true);
            d.setVisible(true);
            g.setVisible(true);
            z.setVisible(true);
            c.setVisible(true);
            b.setVisible(true);
            n.setVisible(true);
            q.setVisible(true);
            e.setVisible(true);
            t.setVisible(true);
            y.setVisible(true);
            i.setVisible(true);
            p.setVisible(true);
            j0.setVisible(true);
            j.setVisible(true);
            l.setVisible(true);
            j2.setVisible(true);
            j3.setVisible(true);
            j5.setVisible(true);
            j7.setVisible(true);
            j9.setVisible(true);
            s.setVisible(true);
            f.setVisible(true);
            x.setVisible(true);
            v.setVisible(true);
            h.setVisible(true);
            w.setVisible(true);
            r.setVisible(true);
            u.setVisible(true);
            o.setVisible(true);
            m.setVisible(true);
            k.setVisible(true);
            j1.setVisible(true);
            j4.setVisible(true);
            j6.setVisible(true);
            j8.setVisible(true);
            doo.setVisible(false);
            re.setVisible(false);
            mi.setVisible(false);
            fa.setVisible(false);
            sol.setVisible(false);
            la.setVisible(false);
            si.setVisible(false);
            doo1.setVisible(false);
            re1.setVisible(false);
            mi1.setVisible(false);
            fa1.setVisible(false);
            sol1.setVisible(false);
            la1.setVisible(false);
            si1.setVisible(false);
            doo2.setVisible(false);
            re2.setVisible(false);
            mi2.setVisible(false);
            fa2.setVisible(false);
            sol2.setVisible(false);
            la2.setVisible(false);
            si2.setVisible(false);
            visible.setVisible(false);
            notVisible.setVisible(true);
        });

        Songs song = new Songs();
        frame.add(song);

        mypanel.setLayout(null);

        Color settingColor = new Color(102, 163, 173);

        mypanel.setBounds(450, 10, 500, 130);
        mypanel.setBackground(settingColor);

        JButton music2 = new JButton();

        JButton music = new JButton();
        music.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//music.png"));
        music.setBorderPainted(false);
        music.setFocusPainted(false);
        music.setContentAreaFilled(false);
        music.setBounds(215, 30, 70, 70);
        music.setVisible(true);
        music.setToolTipText("Выбрать песню");
        mypanel.add(music);
        music.addActionListener(ee -> {
            song.setVisible(true);
            music2.setVisible(true);
            music.setVisible(false);
        });

        music2.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//music.png"));
        music2.setBorderPainted(false);
        music2.setFocusPainted(false);
        music2.setContentAreaFilled(false);
        music2.setBounds(215, 30, 70, 70);
        music2.setVisible(true);
        music2.setToolTipText("Выбрать песню");
        mypanel.add(music2);
        music2.addActionListener(ee -> {
            song.setVisible(false);
            music2.setVisible(false);
            music.setVisible(true);
        });

        JButton res2 = new JButton();

        JButton res = new JButton();
        res.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//re.png"));
        res.setBorderPainted(false);
        res.setFocusPainted(false);
        res.setContentAreaFilled(false);
        res.setBounds(380, 30, 70, 70);
        res.setVisible(true);
        res.setToolTipText("Повторить песню");
        mypanel.add(res);
        res.addActionListener(e3 -> {
            song.setVisible(true);
            res2.setVisible(true);
            res.setVisible(false);
        });

        res2.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//re.png"));
        res2.setBorderPainted(false);
        res2.setFocusPainted(false);
        res2.setContentAreaFilled(false);
        res2.setBounds(380, 30, 70, 70);
        res2.setVisible(true);
        res2.setToolTipText("Повторить песню");
        mypanel.add(res2);
        res2.addActionListener(e3 -> {
            song.setVisible(false);
            res2.setVisible(false);
            res.setVisible(true);
        });

        mypanel.setVisible(false);

        frame.add(mypanel);

        JButton set2 = new JButton();

        JButton set = new JButton();
        set.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Knopka_Nastroyka.png"));
        set.setBorderPainted(false);
        set.setFocusPainted(false);
        set.setContentAreaFilled(false);
        set.setSize(new Dimension(80, 80));
        set.setLocation(1200, 10);
        set.setToolTipText("Открыть панель настройки");
        set.setVisible(true);
        frame.add(set);
        set.addActionListener(e3 -> {
            mypanel.setVisible(true);
            set.setVisible(false);
            set2.setVisible(true);
        });

        set2.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Knopka_Nastroyka.png"));
        set2.setBorderPainted(false);
        set2.setFocusPainted(false);
        set2.setContentAreaFilled(false);
        set2.setSize(new Dimension(80, 80));
        set2.setLocation(1200, 10);
        set2.setToolTipText("Открыть панель настройки");
        set2.setVisible(true);
        frame.add(set2);
        set2.addActionListener(e3 -> {
            mypanel.setVisible(false);
            set2.setVisible(false);
            set.setVisible(true);
        });

        //background picture
        pp.add(contentPane, BorderLayout.NORTH);
        pp.setPreferredSize(new Dimension(1000, 700));
        frame.add(new JScrollPane(pp));

        frame.setPreferredSize(new Dimension(1600,1024));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}