import javax.swing.*;
import java.awt.*;

class Songs extends JPanel {

    Songs() {

        setLayout(null);

        Color settingColor = new Color(102, 163, 173);

        Font font = new Font(Font.SERIF, Font.PLAIN, 20);

        setBounds(300, 150, 800, 100);
        setBackground(settingColor);

        String level1 = "A D G Z C B N Q E T Y I P 0 J J 0 P I Y T E Q N B C Z G D A ";
        JLabel l1 = new JLabel(level1);
        l1.setFont(font);
        l1.setForeground(Color.white);
        l1.setBounds(250, 25, 800, 50);
        l1.setVisible(false);

        String level2 = "C B N G E T U I P 0 J L 2 4 5 5 4 2 L J 0 P I U T E Q N B C";
        JLabel l2 = new JLabel(level2);
        l2.setFont(font);
        l2.setForeground(Color.white);
        l2.setBounds(250, 25, 800, 50);
        l2.setVisible(false);

        String level3 = "A S D F G Z X C V B H N Q W E R T Y U I O P M 0 J  ";
        String level31 = "J 0 M P O I U Y T R E W Q N H B V C X Z G F D S A ";
        JLabel l31 = new JLabel(level31);
        l31.setFont(font);
        l31.setForeground(Color.white);
        l31.setBounds(250, 50, 800, 30);
        l31.setVisible(false);
        JLabel l3 = new JLabel(level3);
        l3.setFont(font);
        l3.setForeground(Color.white);
        l3.setBounds(250, 20, 800, 30);
        l3.setVisible(false);

        JButton song = new JButton("1 уровень");
        JButton song1 = new JButton("1 уровень");
        song1.setBounds(70, 4, 150, 30);
        song1.addActionListener(e5 -> {
            l1.setVisible(true);
            l2.setVisible(false);
            l3.setVisible(false);
            l31.setVisible(false);
            song.setVisible(true);
            song1.setVisible(false);
        });
        song.setBounds(70, 4, 150, 30);
        song.addActionListener(e5 -> {
            l1.setVisible(false);
            l2.setVisible(false);
            l3.setVisible(false);
            l31.setVisible(false);
            song1.setVisible(true);
            song.setVisible(false);
        });

        JButton s = new JButton("2 уровень");
        JButton song2 = new JButton("2 уровень");
        song2.setBounds(70, 35, 150, 30);
        song2.addActionListener(ee -> {
            l2.setVisible(true);
            l1.setVisible(false);
            l3.setVisible(false);
            l31.setVisible(false);
            s.setVisible(true);
            song2.setVisible(false);
        });

        s.setBounds(70, 35, 150, 30);
        s.addActionListener(ee -> {
            l2.setVisible(false);
            l1.setVisible(false);
            l3.setVisible(false);
            l31.setVisible(false);
            s.setVisible(false);
            song2.setVisible(true);
        });


        JButton sg = new JButton("3 уровень");
        JButton song3 = new JButton("3 уровень");
        song3.setBounds(70, 66, 150, 30);
        song3.addActionListener(e -> {
            l3.setVisible(true);
            l31.setVisible(true);
            l1.setVisible(false);
            l2.setVisible(false);
            song3.setVisible(false);
            sg.setVisible(true);
        });

        sg.setBounds(70, 66, 150, 30);
        sg.addActionListener(e -> {
            l3.setVisible(true);
            l31.setVisible(true);
            l1.setVisible(false);
            l2.setVisible(false);
            sg.setVisible(false);
            song3.setVisible(true);
        });

        add(l1);
        add(l2);
        add(l3);
        add(l31);

        add(song1);
        add(song2);
        add(song3);
        add(song);
        add(s);
        add(sg);

        setVisible(false);
    }
}
