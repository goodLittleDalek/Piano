import javax.swing.*;
import java.awt.*;

public class PianoKeys extends JPanel {
    JButton key;
    int KEYS = 36;

        PianoKeys() {
            setLayout(null);

            for (int i = 0; i < KEYS; i++) {
                key = new JButton();
                key.setBackground(Color.white);
                key.setLocation(i * 20, 0);
                key.setSize(20, 120);
                add(key);
                setComponentZOrder(key, i);
            }

            for (int i = 0; i < KEYS; i++) {
                int j = i % 7;
                if (j == 2 || j == 6) continue;
                key = new JButton();
                key.setBackground(Color.black);
                key.setLocation(i * 20 + 12, 0);
                key.setSize(16, 80);
                add(key);
                setComponentZOrder(key, 0);
            }
        }

        int getkey() {
            int pos = 0;
            for (int i = 0; i < KEYS; i++)
            pos += i;
            return pos;
        }
}
