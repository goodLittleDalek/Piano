import javax.swing.*;
import java.awt.*;

class Settings extends JFrame {

    private Font font = new Font(Font.SERIF, Font.PLAIN, 16);

    private Color settingColor = new Color(109, 145, 173);

    void refGUI() {

        JFrame settings = new JFrame("Справка");
        settings.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        settings.getContentPane().setBackground(settingColor);

        settings.setLayout(null);

        JTextArea area = new JTextArea();
        area.setFont(font);

        String text = "   Музыкальные ступени - это приложение, которое поможет\n ребенку обучиться играть на пианино " +
                "быстро и без проблем.\n Ребенок может выбрать из списка песню для игры и исполнить\n ее на виртуальном пианино." +
                " Для начала игры на виртуальном\n пианино необходимо навести курсор на кнопку и нажать на нее.\n Далее можно выполнять " +
                "следующие действия при нажатии на\n следующие кнопки: ";

        area.setText(text);
        area.setBackground(settingColor);
        area.setSize(450, 200);
        settings.add(area);

        JButton music = new JButton();
        music.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//music.png"));
        music.setBorderPainted(false);
        music.setFocusPainted(false);
        music.setContentAreaFilled(false);
        music.setBounds(50, 300, 70, 70);
        music.setVisible(true);
        settings.add(music);

        JLabel m = new JLabel();
        m.setText("Эта кнопка предназначена для выбора песни игры.");
        m.setBounds(150, 300, 350, 50);
        settings.add(m);

        JButton re = new JButton();
        re.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//re.png"));
        re.setBorderPainted(false);
        re.setFocusPainted(false);
        re.setContentAreaFilled(false);
        re.setBounds(50, 370, 70, 70);
        re.setVisible(true);
        settings.add(re);

        JLabel r = new JLabel();
        r.setText("Эта кнопка предназначена для повтора игры.");
        r.setBounds(150, 370, 350, 50);
        settings.add(r);

        JButton notVisible = new JButton();
        notVisible.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//letter.png"));
        notVisible.setBorderPainted(false);
        notVisible.setFocusPainted(false);
        notVisible.setContentAreaFilled(false);
        notVisible.setSize(new Dimension(70, 70));
        notVisible.setLocation(50, 440);
        settings.add(notVisible);

        JLabel nv = new JLabel();
        nv.setText("Эта кнопка предназначена для переключения режимов ");
        nv.setBounds(150, 440, 400, 50);
        settings.add(nv);

        JLabel nv2 = new JLabel();
        nv2.setText("видимости букв и нот клавиш соответственно.");
        nv2.setBounds(150, 460, 400, 50);
        settings.add(nv2);

        JButton set = new JButton();
        set.setIcon(new ImageIcon("D://Study//2 курс//Професійна практика програмної інженерії//проект//piano//src//Igra_Knopka_Nastroyka.png"));
        set.setBorderPainted(false);
        set.setFocusPainted(false);
        set.setContentAreaFilled(false);
        set.setSize(new Dimension(80, 80));
        set.setLocation(50, 210);
        settings.add(set);

        JLabel s = new JLabel();
        s.setText("Это кнопка настроек.");
        s.setBounds(150, 210, 350, 50);
        settings.add(s);

        settings.setPreferredSize(new Dimension(500, 700));
        settings.pack();
        settings.setLocationRelativeTo(null);
        settings.setVisible(true);
    }

}
