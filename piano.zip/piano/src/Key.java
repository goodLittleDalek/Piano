interface Key {
    // change WD to suit your screen
    int WD = 40;
    int HT = 210;
    // change baseNote for starting octave
    //multiples of 16 only
    int baseNote = 48;
    int getNote();
}